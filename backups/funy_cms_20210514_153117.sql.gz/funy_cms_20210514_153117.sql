-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: funy_cms
-- ------------------------------------------------------
-- Server version	5.7.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `account` varchar(60) DEFAULT NULL COMMENT '用户名称',
  `password` varchar(60) DEFAULT NULL COMMENT '密码',
  `description` varchar(255) DEFAULT '' COMMENT '用户描述',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `phone` varchar(60) DEFAULT NULL COMMENT '电话号码',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '软删除时间戳',
  `email` varchar(60) DEFAULT NULL COMMENT '邮箱账号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_account_uindex` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (3,'admin','$2a$14$FazDTlpmEwgYNkNuSNBxy.UamACIDQMKMvyFvBc9x3RPlngJFYIWu','--','http://cdn.surest.cn/iDJFWYmJX6maB6MhGawiZBhsz3xJT8zb','18270952773','2020-11-25 00:25:30','2021-03-28 05:55:29',NULL,'chenf@surest.cn'),(30,'surest','$2a$14$1jIGgCr85FQPj5p4u3cd1ezfX5X10/gytuzzONEfBt3BoPW3HDkIi','123456','http://cdn.surest.cn/iDJFWYmJX6maB6MhGawiZBhsz3xJT8zb','18270952773','2021-03-27 07:40:03','2021-03-28 08:15:32',NULL,'156@qq.com');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `casbin_rule`
--

DROP TABLE IF EXISTS `casbin_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `casbin_rule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p_type` varchar(40) DEFAULT NULL,
  `v0` varchar(40) DEFAULT NULL,
  `v1` varchar(40) DEFAULT NULL,
  `v2` varchar(40) DEFAULT NULL,
  `v3` varchar(40) DEFAULT NULL,
  `v4` varchar(40) DEFAULT NULL,
  `v5` varchar(40) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_index` (`p_type`,`v0`,`v1`,`v2`,`v3`,`v4`,`v5`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `casbin_rule`
--

LOCK TABLES `casbin_rule` WRITE;
/*!40000 ALTER TABLE `casbin_rule` DISABLE KEYS */;
INSERT INTO `casbin_rule` VALUES (113,'g','-','测试角色','','','','','2021-03-27 05:12:23','2021-03-27 05:12:23',NULL),(116,'g','-','测试','','','','','2021-03-27 05:15:41','2021-03-27 05:15:41',NULL),(132,'g','-','运营','','','','','2021-03-28 07:53:43','2021-03-28 07:53:43',NULL),(150,'g','surest','测试','','','','','2021-05-13 08:32:02','2021-05-13 08:32:02',NULL);
/*!40000 ALTER TABLE `casbin_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_record`
--

DROP TABLE IF EXISTS `email_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email_id` tinyint(4) NOT NULL COMMENT '关联的邮件ID',
  `status` int(11) DEFAULT '1' COMMENT '状态: 1: 启用; 2:禁用;',
  `submitter_id` tinyint(4) DEFAULT NULL COMMENT '关联的管理员ID',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='邮件记录关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_record`
--

LOCK TABLES `email_record` WRITE;
/*!40000 ALTER TABLE `email_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_tasks`
--

DROP TABLE IF EXISTS `email_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邮件描述',
  `mailer` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '邮件配置',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '接受人',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '主题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '发送内容',
  `attachments` json NOT NULL COMMENT '附件',
  `status` int(11) DEFAULT '1' COMMENT '状态: 1: 启用; 2:禁用;',
  `submitter_id` tinyint(4) DEFAULT NULL COMMENT '关联的管理员ID',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `send_at` timestamp NULL DEFAULT NULL COMMENT '发送时间',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邮件内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_tasks`
--

LOCK TABLES `email_tasks` WRITE;
/*!40000 ALTER TABLE `email_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '角色名',
  `status` int(11) DEFAULT '1' COMMENT '状态: 1: 启用; 2:禁用;',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色描述',
  `p_id` int(11) DEFAULT '1' COMMENT '父ID',
  `weight` int(11) DEFAULT '1' COMMENT '排序',
  `url` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hidden` int(11) DEFAULT '2' COMMENT '菜单隐藏',
  `component` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '组件',
  `icon` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'ICON',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (2,'权限管理',1,'权限管理',1,9,'/auth',2,NULL,'user',NULL,'2021-03-27 15:02:03','2021-03-28 13:21:02'),(6,'管理员管理',1,'管理员管理',2,2,'/admin/list',2,'views/auth/admin/Index','admin',NULL,'2021-03-28 05:51:12','2021-03-28 13:21:02'),(7,'权限管理',1,'管理员管理',2,2,'/permission',2,'views/auth/permission/Index','admin',NULL,'2021-03-28 05:51:42','2021-03-28 13:21:02'),(8,'角色管理',1,'角色管理',2,2,'/role',2,'views/auth/role/Index','role',NULL,'2021-03-28 05:53:41','2021-03-28 13:21:02'),(9,'菜单管理',1,'菜单管理',2,2,'/menu',2,'views/auth/menu/Index','menu',NULL,'2021-03-28 05:54:03','2021-03-28 13:21:02'),(12,'hidden',NULL,'hidden',NULL,NULL,'hidden',NULL,'hidden','hidden',NULL,'2021-03-28 13:35:48','2021-03-28 13:35:48'),(13,'邮件管理',1,'邮件管理',1,1,'/mail',2,'','email',NULL,'2021-05-13 09:03:25','2021-05-13 09:04:28'),(14,'发送列表',1,'发送列表',13,0,'',2,'views/mail/Index','email',NULL,'2021-05-13 09:03:48','2021-05-13 09:03:48');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分类: 根据业务类型进行定义',
  `description` json NOT NULL COMMENT '详细信息',
  `submitter_id` tinyint(4) DEFAULT NULL COMMENT '发送者',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='消息通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_user`
--

DROP TABLE IF EXISTS `notification_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `notification_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `follow_id` tinyint(4) DEFAULT NULL COMMENT '跟进人',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='消息通知关联用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_user`
--

LOCK TABLES `notification_user` WRITE;
/*!40000 ALTER TABLE `notification_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限名',
  `icon` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT 'link' COMMENT '权限图标',
  `url` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '路径',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态: 1:正常; 2禁用',
  `method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'GET' COMMENT '方法名称',
  `p_id` int(11) DEFAULT '1' COMMENT '节点位置 1:根结点;',
  `hidden` tinyint(4) DEFAULT '2' COMMENT '是否隐藏 1:是 2否',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=690 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (678,'角色详情','link','/api/role/show',1,'GET',676,2,'2021-03-27 04:54:46','2021-03-27 05:25:32',NULL),(677,'角色列表','link','/api/role',1,'GET',671,2,'2021-03-27 04:54:46','2021-03-27 05:25:13',NULL),(676,'管理员详情','link','/api/admin/show',1,'GET',671,2,'2021-03-27 04:54:46','2021-03-27 05:25:35',NULL),(671,'根节点','link','',1,'any',0,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(672,'权限列表','link','/api/permission',1,'GET',671,2,'2021-03-27 04:54:46','2021-03-27 05:25:42',NULL),(673,'权限详情','link','/api/permission/show',1,'GET',671,2,'2021-03-27 04:54:46','2021-03-27 05:25:49',NULL),(674,'权限树','link','/api/permission/tree',1,'GET',671,2,'2021-03-27 04:54:46','2021-03-27 05:25:57',NULL),(675,'管理员列表','link','/api/admin',1,'GET',671,2,'2021-03-27 04:54:46','2021-03-27 05:26:04',NULL),(679,'七牛云秘钥','link','/api/qiniu',1,'GET',671,2,'2021-03-27 04:54:46','2021-03-27 05:26:16',NULL),(680,'管理员创建','link','/api/admin/store',1,'POST',671,2,'2021-03-27 04:54:46','2021-03-27 05:26:37',NULL),(681,'/api/permission/store','link','/api/permission/store',1,'POST',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(682,'/api/role/store','link','/api/role/store',1,'POST',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(683,'/api/logout','link','/api/logout',1,'DELETE',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(684,'/api/admin/delete','link','/api/admin/delete',1,'DELETE',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(685,'/api/permission/delete','link','/api/permission/delete',1,'DELETE',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(686,'/api/role/delete','link','/api/role/delete',1,'DELETE',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(687,'/api/admin/save','link','/api/admin/save',1,'PUT',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(688,'/api/permission/save','link','/api/permission/save',1,'PUT',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL),(689,'/api/role/save','link','/api/role/save',1,'PUT',671,2,'2021-03-27 04:54:46','2021-03-27 04:54:46',NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '角色名',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色描述',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `status` int(11) DEFAULT '1' COMMENT '状态: 1: 启用; 2:禁用;',
  `menu_ids` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '拥有的菜单',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (20,'测试','测试','2021-03-27 05:15:41','2021-05-13 08:42:55',NULL,1,'[]');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-14 15:31:17
